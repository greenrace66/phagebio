var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var create_order_exports = {};
__export(create_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_order_exports);
const Razorpay = require("razorpay");
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || "rzp_test_YourTestKeyHere";
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "YourTestSecretHere";
const razorpay = new Razorpay({
  key_id: RAZORPAY_KEY_ID,
  key_secret: RAZORPAY_KEY_SECRET
});
async function handler(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: "Method not allowed" })
    };
  }
  try {
    const { plan } = JSON.parse(event.body || "{}");
    const amount = 1900 * 100;
    const currency = "INR";
    const receipt = `receipt_premium_${Date.now()}`;
    const order = await razorpay.orders.create({
      amount,
      currency,
      receipt,
      payment_capture: 1
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ order })
    };
  } catch (err) {
    console.error("Error creating Razorpay order:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to create order" })
    };
  }
}
;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
